﻿/*
 * Create a function on each shape tp assign adjacent shapes to GameObject[] variable ( For Checking if Swappable )
 * use RayCast or Collision to get adjacent Shapes ( Unless u got better method ) 
 * Run the Function only at Game Start ( After Shapes Fall ) and Right Afte Swapping
 *  
 *  
 * Use Adjacent Blocks to check if they're any viable moves left 
*/

